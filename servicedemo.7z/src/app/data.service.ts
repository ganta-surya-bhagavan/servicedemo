import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders} from '@angular/common/http'
import { Observable, throwError } from 'rxjs';
import { Localbook } from './Localbook';
import { retry,catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class DataService {
  data: Object;
  baseurl: string = 'https://jsonplaceholder.typicode.com/posts';
  
  constructor(private http: HttpClient) { }
  httpOptions = {
    header: new HttpHeaders({
      'Content-Type' : 'application/json'
    })
  }
  GetLocalBooks(): Observable<Localbook>{
    return this.http.get<Localbook>(this.localurl).pipe(retry(1),catchError(this.errorHandl));
  }
  
  errorHandl(error){
    /* let errorMessage='';
   if(error.error instanceof ErrorEvent){
     errorMessage = error.error.message;
   }
   else{
     errorMessage=`Error Code: ${error.status}\nMessage:`
   }*/
    
   return throwError("error");
  }
  
  localurl:string='https://jsonplaceholder.typicode.com/posts';
  myData(){
    return 'This is the data from my DataService';
  }
  PostNewBook() : any {
    
    console.log("inside PostNewBook() of DataService");
    this.http
    .post(
      this.baseurl,
      JSON.stringify({
        body : 'bar',
        title : 'foo',
        userId: 1
      })
    )
    .subscribe(data => {
      this.data=data;
    })
  }
  

}
