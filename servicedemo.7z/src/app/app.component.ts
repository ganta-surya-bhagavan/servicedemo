import { Component, OnInit } from '@angular/core';
import { DataService } from './data.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'servicedemo';
  somedata:string=' ';
  localbookList: any[];
 constructor(private ds : DataService){};
  ngOnInit(){
    this.somedata=this.ds.myData();
    this.loadlocalbooks();
  }
  loadlocalbooks() {
   return this.ds.GetLocalBooks().subscribe( (data : any) =>{ this.localbookList=data;});
  }
}
